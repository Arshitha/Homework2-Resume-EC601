# Homework2-Resume-EC601
Personal portfolio page built using a bootstrap template as part of Product Design course (EC601)

# Bootstrap Template 
In order to build this portfolio page, I used an open source bootstrap template. 
Link: https://startbootstrap.com/template-overviews/resume/

# Viewing
To view the page, download all the files in the repository on your local machine and open the
index.html page.

# Credits (Copyright and License)

Copyright 2013-2017 Blackrock Digital LLC. Code released under the [MIT](https://github.com/BlackrockDigital/startbootstrap-resume/blob/gh-pages/LICENSE) license.


